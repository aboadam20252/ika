import Parent from './dummy.js';

class Page extends Parent {

    init() {
        this.ikariamPremiumToggle([$('#townHall .premiumOffer')]);
    }
}

export default Page;
