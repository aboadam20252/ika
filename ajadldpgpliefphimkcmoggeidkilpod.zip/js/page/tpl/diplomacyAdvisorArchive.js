﻿import Parent from './diplomacyAdvisor.js';

class Page extends Parent {

}

export default Page;
