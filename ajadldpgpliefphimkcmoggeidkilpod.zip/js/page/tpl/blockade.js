﻿import Parent from './plunder.js';

class Page extends Parent {

    init() {
        this.addButtons();
    }

}

export default Page;
