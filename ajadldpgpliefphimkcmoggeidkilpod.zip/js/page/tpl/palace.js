import Parent from './dummy.js';

class Page extends Parent {

    init() {
        // Обновляем форму правления
        // this._ieData.info.set('government', $('.government_pic img').attr('src').slice(16, -8));
    }

}

export default Page;
