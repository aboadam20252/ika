export default {
    "ikalogs_save_log": "Αποθήκευση καταγραφής",
    "ikalogs_each": "Κάθε",
    "ikalogs_help_bw": "Γύροι σε λίστα χωρισμένη με κόμμα ή ένα εύρος γύρων μέσω παύλας.",
    "ikalogs_analyze": "Ανάλυση",
    "ikalogs_get_info": "Λήψη δεδομένων",
    "ikalogs_get_rounds": "Λήψη καταγραφής",
    "ikalogs_saving": "Αποθήκευση καταγραφής",
    "ikalogs_saving_success": "Η καταγραφή αποθηκεύτηκε επιτυχώς.",
    "ikalogs_open_report": "Άνοιγμα καταγραφής",
    "ikalogs_saving_failed": "Απέτυχε η αποθήκευση της καταγραφής",
    "ikalogs_repeat": "Δοκιμάστε ξανά",
    "ikalogs_not_logged": "Δεν έχετε συνδεθεί στο Ikalogs",
    "ikalogs_types_full": "Πλήρης καταγραφή",
    "ikalogs_types_short": "Περιληπτική καταγραφή",
    "ikalogs_types_last": "Τελευταίος γύρος",
    "ikalogs_types_each": "Κάθε Νο γύρο",
    "ikalogs_types_between": "Συμπαγείς γύροι"
};