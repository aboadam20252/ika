import Parent from '../../../_dummy.js';

class PrepareTpl extends Parent {
    constructor(data) {
        super(data);
    }
}

export default PrepareTpl;
