import Parent from './dummy.js';

class Page extends Parent {

    init() {
    }

}

export default Page;
