// Подключаем initModule чтобы потом нормально работать с импортами
import('./initModule.js');
